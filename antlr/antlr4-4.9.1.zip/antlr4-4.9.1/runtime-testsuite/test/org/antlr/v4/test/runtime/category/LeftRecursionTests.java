package org.antlr.v4.test.runtime.category;

/**
 * Created by ericvergnaud on 27/06/2017.
 */
public class LeftRecursionTests {
}
