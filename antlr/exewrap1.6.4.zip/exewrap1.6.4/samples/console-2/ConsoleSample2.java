import java.io.IOException;

public class ConsoleSample2 {

	public static void main(String[] args) throws IOException {

		System.out.println("Hello, World!!");

		System.out.println("Enterキーを押すと終了します。");
		System.in.read();

	}
}
