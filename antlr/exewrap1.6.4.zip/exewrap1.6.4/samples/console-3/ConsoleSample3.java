
public class ConsoleSample2 {

	public static void main(String[] args) {

		System.out.println("java.runtime.version=" + System.getProperty("java.runtime.version"));
		System.out.println("JAVA_HOME=" + System.getenv("JAVA_HOME"));

	}
}
