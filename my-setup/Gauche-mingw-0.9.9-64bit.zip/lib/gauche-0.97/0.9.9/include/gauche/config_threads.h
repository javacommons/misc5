/* Generated automatically from gc config header; do not edit. */
#define GC_THREADS 1
