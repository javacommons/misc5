/*
 * @@extname@@.h
 */

/* Prologue */
#ifndef GAUCHE_@@EXTNAME@@_H
#define GAUCHE_@@EXTNAME@@_H

#include <gauche.h>
#include <gauche/extend.h>

SCM_DECL_BEGIN

/*
 * The following entry is a dummy one.
 * Replace it for your declarations.
 */

extern ScmObj test_@@extname@@(void);

/* Epilogue */
SCM_DECL_END

#endif  /* GAUCHE_@@EXTNAME@@_H */
